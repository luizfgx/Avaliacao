package br.trimestral.senai.trimestral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrimestralApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrimestralApplication.class, args);
	}

}
